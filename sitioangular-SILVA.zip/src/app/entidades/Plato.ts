export class Plato { 
    id: string;
    nombre: string; 
    precio: string; 
    rubro: string; 
    imagenPath: string; 
    ingredientes: string[]; 
}